package lesson4;
import java.util.Arrays;

public class Oderstatistics {

	public static int KthSmallest(Integer[] arr,int k) {
		
		Arrays.sort(arr);
	
		
		return arr[k-1]; 		
	}
	
	public static void main(String[] args) {
		
		Integer arr[]= new Integer[] {7,2,3,78,98,45,76};
		
		int k=4; 
		
		System.out.println("Kth Smallest Element is : "+ KthSmallest(arr, k) );
	}
}
