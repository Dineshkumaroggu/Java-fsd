package lesson3;

public class Threadextenddemo extends Thread {
	//method over loading
	public void run() {
		System.out.println("thread Started Sucessfully");
	}
	
	public static void main(String[] args) {
		
		Threadextenddemo t1= new Threadextenddemo();
		Threadextenddemo t2= new  Threadextenddemo();
		
		t1.start();
		t2.start();
	}
}
